﻿
namespace ListeFilms
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.vUENBPLACEPARFILMBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mONCINEMA6DataSet = new ListeFilms.MONCINEMA6DataSet();
            this.vUETITREFILMORDREALPHABETIQUEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.vUE_TITRE_FILM_ORDRE_ALPHABETIQUETableAdapter = new ListeFilms.MONCINEMA6DataSetTableAdapters.VUE_TITRE_FILM_ORDRE_ALPHABETIQUETableAdapter();
            this.vUE_NBPLACE_PAR_FILMTableAdapter = new ListeFilms.MONCINEMA6DataSetTableAdapters.VUE_NBPLACE_PAR_FILMTableAdapter();
            this.vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACETableAdapter = new ListeFilms.MONCINEMA6DataSetTableAdapters.VUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACETableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.vUENBPLACEPARFILMBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONCINEMA6DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vUETITREFILMORDREALPHABETIQUEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(116, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Liste des films";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.vUENBPLACEPARFILMBindingSource;
            this.comboBox1.DisplayMember = "titre";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(109, 100);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(267, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.ValueMember = "SOMME_PLACE";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // vUENBPLACEPARFILMBindingSource
            // 
            this.vUENBPLACEPARFILMBindingSource.DataMember = "VUE_NBPLACE_PAR_FILM";
            this.vUENBPLACEPARFILMBindingSource.DataSource = this.mONCINEMA6DataSet;
            // 
            // mONCINEMA6DataSet
            // 
            this.mONCINEMA6DataSet.DataSetName = "MONCINEMA6DataSet";
            this.mONCINEMA6DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vUETITREFILMORDREALPHABETIQUEBindingSource
            // 
            this.vUETITREFILMORDREALPHABETIQUEBindingSource.DataMember = "VUE_TITRE_FILM_ORDRE_ALPHABETIQUE";
            this.vUETITREFILMORDREALPHABETIQUEBindingSource.DataSource = this.mONCINEMA6DataSet;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(106, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre total des places pour le film choisi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(328, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "label3";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(109, 219);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(313, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Extraction des réservations en fichier csv pour le film choisi";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // vUE_TITRE_FILM_ORDRE_ALPHABETIQUETableAdapter
            // 
            this.vUE_TITRE_FILM_ORDRE_ALPHABETIQUETableAdapter.ClearBeforeFill = true;
            // 
            // vUE_NBPLACE_PAR_FILMTableAdapter
            // 
            this.vUE_NBPLACE_PAR_FILMTableAdapter.ClearBeforeFill = true;
            // 
            // vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource
            // 
            this.vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource.DataMember = "VUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACE";
            this.vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource.DataSource = this.mONCINEMA6DataSet;
            // 
            // vUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACETableAdapter
            // 
            this.vUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACETableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vUENBPLACEPARFILMBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mONCINEMA6DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vUETITREFILMORDREALPHABETIQUEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private MONCINEMA6DataSet mONCINEMA6DataSet;
        private System.Windows.Forms.BindingSource vUETITREFILMORDREALPHABETIQUEBindingSource;
        private MONCINEMA6DataSetTableAdapters.VUE_TITRE_FILM_ORDRE_ALPHABETIQUETableAdapter vUE_TITRE_FILM_ORDRE_ALPHABETIQUETableAdapter;
        private System.Windows.Forms.BindingSource vUENBPLACEPARFILMBindingSource;
        private MONCINEMA6DataSetTableAdapters.VUE_NBPLACE_PAR_FILMTableAdapter vUE_NBPLACE_PAR_FILMTableAdapter;
        private System.Windows.Forms.BindingSource vUETITRERESERVATIONNOMPRENOMNBPLACEBindingSource;
        private MONCINEMA6DataSetTableAdapters.VUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACETableAdapter vUE_TITRE_RESERVATION_NOM_PRENOM_NB_PLACETableAdapter;
    }
}

